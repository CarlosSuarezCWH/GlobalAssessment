import mysql.connector
mydb = mysql.connector.connect(
  host="cwh1.kiubix.biz",
  user="fpryvvyl_cwg",
  password="FELDqXHfgTxv",
  database="fpryvvyl_global"

)
mycursor = mydb.cursor()